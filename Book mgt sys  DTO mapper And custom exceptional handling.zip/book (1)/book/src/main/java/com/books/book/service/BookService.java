package com.books.book.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.books.book.dto.BookDTO;
import com.books.book.exception.BookNotFoundException;
import com.books.book.exception.DuplicateBookException;
import com.books.book.mapper.BookMapper;
import com.books.book.model.Book;
import com.books.book.repository.BookRepository;
@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;
    
    public List<BookDTO> getBook(){
        return bookRepository.findAll()
            .stream()
            .map(BookMapper::toDto)
            .toList();
    }

    public BookDTO getBookById(UUID id){
        Book book = bookRepository.findById(id)
           .orElseThrow(()-> new BookNotFoundException("Book With This Id"+ id +" Is Not Found"));
        return BookMapper.toDto(book);
    }

    public void createBook(BookDTO bookDTO){
        Optional<Book> b = bookRepository.findByTitle(bookDTO.getTitle());
        if (b.isPresent()) {
            throw new DuplicateBookException("Book With this title "+ bookDTO.getTitle() +"Exists");
        }else{
            Book book = BookMapper.toEntity(bookDTO);
            bookRepository.save(book);
        }
    }

    public void deleteBook(UUID id){
        if (!bookRepository.existsById(id)) {
            throw new BookNotFoundException("Book with this Id"+ id + "Not Exist");
        }
        bookRepository.deleteById(id);
    }

    public void updateBook(BookDTO bookDTO, UUID id){
        Book bb = bookRepository.findById(id)
            .orElseThrow(()-> new BookNotFoundException("Book With this id Not Exist"));
        
        bb.setTitle(bookDTO.getTitle());
        bb.setAuthor(bookDTO.getAuthor());
        bb.setPages(bookDTO.getPages());
        bookRepository.save(bb);
    }
}
