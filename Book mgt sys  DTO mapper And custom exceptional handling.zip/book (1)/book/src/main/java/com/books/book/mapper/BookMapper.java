package com.books.book.mapper;

import com.books.book.dto.BookDTO;
import com.books.book.model.Book;

public class BookMapper {
    public static BookDTO toDto(Book book){
        BookDTO dto = new BookDTO();
        dto.setId(book.getId());
        dto.setTitle(book.getTitle());
        dto.setAuthor(book.getAuthor());
        dto.setPages(book.getPages());
        return dto;
    }

    public static Book toEntity(BookDTO bookDTO){
        Book dto = new Book();
        dto.setTitle(bookDTO.getTitle());
        dto.setAuthor(bookDTO.getAuthor());
        dto.setPages(bookDTO.getPages());
        return dto;
    }
}
