package com.books.book.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import com.books.book.dto.BookDTO;
import com.books.book.service.BookService;

@RestController
@RequestMapping(value = "/api/book")
public class BookController {
    @Autowired
    private BookService bookService;

    @GetMapping(value = "/getBook")
    public ResponseEntity<List<BookDTO>> getBook(){
        List<BookDTO> b = bookService.getBook();
        return ResponseEntity.ok(b);
    }

    @GetMapping(value = "/getBookById/{id}")
    public ResponseEntity<?> getBookById(@PathVariable UUID id){
        bookService.getBookById(id);
        return ResponseEntity.ok(bookService.getBookById(id));
    }
    @PostMapping(value = "/createBook", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createBook(@RequestBody BookDTO bookDTO){
        bookService.createBook(bookDTO);
            return ResponseEntity.ok("created");
    }
    
    @DeleteMapping(value = "/deleteBook/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable UUID id){
        bookService.deleteBook(id);
            return ResponseEntity.ok("deleted");
    }

    @PutMapping(value = "/updateBook/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateBook(@RequestBody BookDTO bookDTO, @PathVariable UUID id){
        bookService.updateBook(bookDTO, id);
            return ResponseEntity.ok("updated");
    }
}
